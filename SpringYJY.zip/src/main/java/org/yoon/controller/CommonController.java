package org.yoon.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.yoon.domain.MemberVO;
import org.yoon.domain.ReplyVO;
import org.yoon.mapper.MemberMapper;
import org.yoon.service.BoardService;
import org.yoon.service.MemberService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@AllArgsConstructor
@RequestMapping("/member/*")
public class CommonController {
	
	private MemberService service;
	
	//���������� â���� �̵�
	@GetMapping("Myprofile")
	public void profile() {
		log.info("���������� â���� �̵�");
	}
	
	//ȸ������ â���� �̵�
	@GetMapping("customRegister")
	public void Register() {
		log.info("ȸ������ â���� �̵�");
	}
	
	//ȸ�� ���
	@PostMapping("/customRegister")
	public String Register(MemberVO vo, RedirectAttributes rttr) {
		log.info("ȸ����� post");
				
		service.insert(vo);	
	
		return "redirect:/member/customLogin";
	} 

	//�α��� â���� �̵�
	@GetMapping("/customLogin")
	public void login(String error, String logout, Model model) {
		log.info("error: "+error);
		log.info("logout: "+logout);
		
		if(error != null) {
			model.addAttribute("error", "�α��� ���� �߻�!! ������ Ȯ�����ּ���");
		}
		if(logout != null) {
			model.addAttribute("logout", "�α׾ƿ�");
		}
	}
	
	//�α׾ƿ� â���� �̵�
	@GetMapping("/customLogout")
	public void logoutGet() {
		log.info("�α׾ƿ�");
	}
	
	@PostMapping("/customLogout")
	public void logoutPost() {
		log.info("post �α׾ƿ�");	
	}
	
	//id�ߺ�üũ
	@GetMapping("/idCheckService")
	@ResponseBody
	public int idCheck(@RequestParam("userid") String id) {
		int result=service.idCheck(id);
		if(result == 1) {
			return 1;
		}else {
			return 0;
		}
	}
	
	
}
